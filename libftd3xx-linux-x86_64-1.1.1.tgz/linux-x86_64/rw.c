#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "ftd3xx.h"

#define FIFO_CHANNEL_1	0
#define FIFO_CHANNEL_2	1
#define FIFO_CHANNEL_3	2
#define FIFO_CHANNEL_4	3
#define TIMEOUT			0 //0xFFFFFFFF

static void show_help(const char *bin)
{
	printf("Usage: %s <write length> <read length>\r\n", bin);
	printf("  Only FT245 mode is supported in this demo\r\n");
}

int main(int argc, char *argv[])
{
	FT_HANDLE handle = NULL;
    unsigned short vendorId;
    unsigned short productId;


	if (argc != 3) {
		show_help(argv[0]);
		return false;
	}
	uint32_t to_write = atoi(argv[1]);
	uint32_t to_read = atoi(argv[2]);

	FT_Create(0, FT_OPEN_BY_INDEX, &handle);

	if (!handle) {
		printf("Failed to create device\r\n");
		return -1;
	}
	printf("Device created\r\n");


    FT_STATUS ftStatus = FT_GetVIDPID(handle,&vendorId,&productId);
    if (ftStatus != FT_OK)
    {
        (void)printf("FT_GetVIDPID failed %d\n",ftStatus);
    }
    (void)printf("\tVendor ID: 0x%04X\n\tProduct ID: 0x%04X\n",vendorId, productId);


	
    FT_SetPipeTimeout(handle,0x02,0);
    FT_SetPipeTimeout(handle,0x82,0);
    
	uint8_t *out_buf = (uint8_t *)malloc(to_write);
	uint8_t *in_buf = (uint8_t *)malloc(to_read);
	DWORD count;

	if (FT_OK != FT_WritePipeEx(handle, FIFO_CHANNEL_1, out_buf, to_write,
				&count, TIMEOUT)) {
		printf("Failed to write\r\n");
		goto _Exit;
	}
	printf("Wrote %d bytes\r\n", count);

	if (FT_OK != FT_ReadPipeEx(handle, FIFO_CHANNEL_1, in_buf, to_read,
				&count, TIMEOUT)) {
		printf("Failed to read\r\n");
		goto _Exit;
	}
	printf("Read %d bytes\r\n", count);

_Exit:
	free(in_buf);
	free(out_buf);
	FT_Close(handle);
	return 0;
}
